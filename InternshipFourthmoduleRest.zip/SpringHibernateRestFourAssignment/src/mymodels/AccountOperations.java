package mymodels;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.springframework.stereotype.Service;


import myentities.Account;
import myentities.Transactions;

@Service
public class AccountOperations 
{
	
	public Account searchAccbyAccno(String accno)
	{
		Account acc = new Account();
		
		try
		{
			Session ses;
			Configuration cfg=new Configuration().configure();
			SessionFactory sf=cfg.addAnnotatedClass(Account.class).buildSessionFactory();
			ses=sf.getCurrentSession();
			ses.beginTransaction();

			Query q=ses.createQuery("from Account where accno=:id ");
			q.setParameter("id",accno);
			List lst=q.getResultList();
			if(lst.size()>0)
			{
				acc=(Account) lst.get(0);
			}
			
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		
		return acc;
	}
	
	public ArrayList<Account> getAllAccounts()
	{
		ArrayList<Account> alist = new ArrayList<Account>();
		
		try
		{
			Session ses;
			Configuration cfg=new Configuration().configure();
			SessionFactory sf=cfg.addAnnotatedClass(Account.class).buildSessionFactory();
			ses=sf.getCurrentSession();
			ses.beginTransaction();

			Query q=ses.createQuery("from Account");
			alist = (ArrayList<Account>)q.getResultList();
			
			
			
		}
		catch (Exception e) 
		{
			System.out.println("Exception :" +e);
		}
		
		return alist;
	}
	
	public ArrayList<Account> searchAccbyType(String type)
	{
ArrayList<Account> alist = new ArrayList<Account>();
		
		try
		{
			Session ses;
			Configuration cfg=new Configuration().configure();
			SessionFactory sf=cfg.addAnnotatedClass(Account.class).buildSessionFactory();
			ses=sf.getCurrentSession();
			ses.beginTransaction();
			
			Query q=ses.createQuery("from Account where acctype=:id ");
			q.setParameter("id",type);
			alist = (ArrayList<Account>)q.getResultList();
			
			
			
		}
		catch (Exception e) 
		{
			System.out.println("Exception :" +e);
		}
		
		return alist;
	}
	
	public String deleteAccountByAccno(String accno)
	{
		String status="failed";
		
		try
		{
			Session ses;
			Configuration cfg=new Configuration().configure();
			SessionFactory sf=cfg.addAnnotatedClass(Account.class).buildSessionFactory();
			ses=sf.getCurrentSession();
			ses.beginTransaction();
			
			Query q=ses.createQuery("delete from Account where accno=:id ");
			q.setParameter("id",accno);
			int i=q.executeUpdate();
			if(i>0)
			{
				ses.getTransaction().commit();
				status="success";
			}
		}
		catch (Exception e) 
		{
			System.out.println("Exception :" +e);
		}
		
		return status;
	}
	
	public int createAccount(Account acc)
	{
		int i=0;
		try
		{
			 Session Ses;
			    Configuration cfg=new Configuration().configure();
			    SessionFactory sf=cfg.addAnnotatedClass(Account.class).buildSessionFactory();

			    Ses=sf.getCurrentSession();
			    Ses.beginTransaction();
			    Ses.save(acc);
			    Ses.getTransaction().commit();
			    i=1;
			
		}
		catch (Exception e) 
		{
			// TODO: handle exception
			System.out.println("Exception :" +e);
			
		}
		
		
		return i;
	}
	
	public String transferAmt(Transactions trans)
	{
		String status="failed";
		try
		{
		 Session Ses;
		    Configuration cfg=new Configuration().configure();
		    SessionFactory sf=cfg.addAnnotatedClass(Transactions.class).buildSessionFactory();
		    SimpleDateFormat formatter = new SimpleDateFormat("dd MMM yyyy");
		    Date date = new Date();
		    String dt=formatter.format(date);
		    date=formatter.parse(dt);
		    trans.setTransdt(date);
		    
		    Ses=sf.getCurrentSession();
		    Ses.beginTransaction();
		    Ses.save(trans);
		    Ses.getTransaction().commit();
		   
		    
		    Session ses1;
			Configuration cfg1=new Configuration().configure();
			SessionFactory sf1=cfg1.addAnnotatedClass(Account.class).buildSessionFactory();
			ses1=sf1.getCurrentSession();
			ses1.beginTransaction();
			
			Query q1=ses1.createQuery("update Account set balance=balance-:bal where accno=:accno ");
			q1.setParameter("bal",trans.getAmount());
			q1.setParameter("accno",trans.getFromacno());
			int i=q1.executeUpdate();
			if(i>0)
			{
				ses1.getTransaction().commit();
			
			
			 Session ses2;
				Configuration cfg2=new Configuration().configure();
				SessionFactory sf2=cfg1.addAnnotatedClass(Account.class).buildSessionFactory();
				ses2=sf2.getCurrentSession();
				ses2.beginTransaction();
				
				Query q2=ses2.createQuery("update Account set balance=balance+:bal where accno=:accno ");
				q2.setParameter("bal",trans.getAmount());
				q2.setParameter("accno",trans.getToacno());
				i=q2.executeUpdate();
				if(i>0)
				{
					ses2.getTransaction().commit();
					 status="success";
				}
		    
		   
			}
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("Exception :" +e);
		}
		
		return status;
	}
	
	
	
	
	

}

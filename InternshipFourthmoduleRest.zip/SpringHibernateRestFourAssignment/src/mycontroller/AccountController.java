package mycontroller;


import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



import myentities.Account;
import myentities.Transactions;
import mymodels.AccountOperations;


@RestController
@RequestMapping("/api")
public class AccountController 
{
	
	@Autowired
	private AccountOperations accop;
	
	@GetMapping("/searchacc/{accno}")
	public Account searchAccbyNo(@PathVariable(value = "accno") String accno)
	{
		
		Account acc = accop.searchAccbyAccno(accno);
		return acc;
	}
	
	@GetMapping("/allaccounts")
	public ArrayList<Account> showAllAccounts()
	{
		ArrayList<Account> alist =accop.getAllAccounts();
		return alist;
	}
	
	@GetMapping("/searchacctype/{type}")
	public ArrayList<Account> searchAccbyType(@PathVariable(value = "type") String type)
	{
		ArrayList<Account> alist =accop.searchAccbyType(type);
		return alist;
	}
	
	@DeleteMapping("/deleteacc/{accno}")
	public String deleteAccount(@PathVariable(value = "accno") String accno)
	{

		 String status=accop.deleteAccountByAccno(accno);
		return status;
	}
	
	@PostMapping(path="/newaccount")
	public ResponseEntity<String> newAccounts(@RequestBody Account acc)
	{
		String msg="Account Creation Failed..";
		int n=accop.createAccount(acc);
		if (n>0) 
		{
			msg="Account Created Successfully...";
		}
		return new ResponseEntity<String>(msg,HttpStatus.OK);
	}
	
	@PostMapping("/transferamt")
	public String transferAmount(@RequestBody Transactions trans)
	{
		String status=accop.transferAmt(trans);
		return status;
		
	}
	
	

}
